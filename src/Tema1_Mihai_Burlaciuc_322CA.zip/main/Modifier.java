package main;

public class Modifier {
	private float modfierRogue;
	private float modfierKnight;
	private float modfierPyromancer;
	private float modfierWizard;

	/**
	 * getter modificator.
	 * @return
	 */
	public float getModfierRogue() {
		return modfierRogue;
	}

	/**
	 * setter modificator.
	 * @param modfierRogue
	 */
	public void setModfierRogue(final float modfierRogue) {
		this.modfierRogue = modfierRogue;
	}

	/**
	 * getter modificator.
	 * @return
	 */
	public float getModfierKnight() {
		return modfierKnight;
	}

	/**
	 * setter modificator.
	 * @param modfierKnight
	 */
	public void setModfierKnight(final float modfierKnight) {
		this.modfierKnight = modfierKnight;
	}

	/**
	 * getter modificator.
	 * @return
	 */
	public float getModfierPyromancer() {
		return modfierPyromancer;
	}

	/**
	 * setter modificator.
	 * @param modfierPyromancer
	 */
	public void setModfierPyromancer(final float modfierPyromancer) {
		this.modfierPyromancer = modfierPyromancer;
	}

	/**
	 * getter modificator.
	 * @return
	 */
	public float getModfierWizard() {
		return modfierWizard;
	}

	/**
	 * setter modificator.
	 * @param modfierWizard
	 */
	public void setModfierWizard(final float modfierWizard) {
		this.modfierWizard = modfierWizard;
	}
}
